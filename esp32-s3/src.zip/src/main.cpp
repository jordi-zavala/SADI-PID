#include <Arduino.h>
#include <math.h>
#include <LittleFS.h>
#include <semphr.h>

#include "Configuracion_Esp_32/Variables_del_sistema.h"
#include "Configuracion_Esp_32/Pines_Incubadora.h"
#include "Configuracion_Esp_32/Configuracion_Wifi.h"
#include "Configuracion_Esp_32/Configuracion_Del_sensor.h"
#include "Configuracion_Esp_32/Freertos.h"

// Configuración de pines.


bool WiFi_Conectado = false;

const byte DNS_PORT = 53;


// Configuración del controlador PID.
// El metodo de sintonización es el metodo IMC
void Configuracion_PID(float Tau, float Retardo_sys, float Retardo_Sensor, float Gananica_Planta)
{
  constexpr double Kp = (Tau * 0.6) /
                        (Gananica_Planta * (Retardo_Sensor + Retardo_sys + Tiempo_de_Muestreo) * 2.0),
                   Ti = Tiempo_de_Subida_Sistema,
                   Td = 0.0,

                   // El sistema determina los valores PID Discretos.
      Kid = (Kp * Tiempo_de_Muestreo) / Ti,
                   Kdd = (Kp * Td) / Tiempo_de_Muestreo,
                   Kpd = Kp;
  return Kid, Kdd, Kpd;
}

//Se ejecuta un scaneo de las redes wifi cercanas para posteriormente...
//Guardarse en memoria la configuración de red.


constexpr int Nd = 1;

unsigned long Tiempo_Actual, Tiempo_Anterior, chars;

//Función que permite realizar un control respectivo de los actuadores pertenecientes al sistema.
void Controlar_Actudadores(int pwmIzq, int pwmDer, bool EnableA, bool EnableB,)
{
  if (girarIzq && !girarDer)
  {
    digitalWrite(dirIzq, HIGH);
    digitalWrite(dirDer, LOW);
    ledcWrite(pwmIzq, velocidad);
    ledcWrite(pwmDer, 0);
  }
  else if (!girarIzq && girarDer)
  {
    digitalWrite(dirIzq, LOW);
    digitalWrite(dirDer, HIGH);
    ledcWrite(pwmIzq, 0);
    ledcWrite(pwmDer, velocidad);
  }
  else
  {
    digitalWrite(dirIzq, LOW);
    digitalWrite(dirDer, LOW);
    ledcWrite(pwmIzq, 0);
    ledcWrite(pwmDer, 0);
  }
}

void Configuracion_Del_Scope(){
  
}

void Lectura_de_sensores(void *)
{
  TickType_t Ultimo = xTaskGetTickCount();
  for (;;)
  {
    // Se desarrolla la configuración mediante FreeRTOS del sistema para el sensor DHT22
    float Lectura_De_Temperatura_Incubadora = dht1.readTemperature();
    float Lectura_De_Humedad_Incubadora = dht1.readHumidity();
    // Recordar que el UFF del sistema de la temperatura en un sistema incubador posee mayor logica.
    float Lectura_De_Temperatura_Ambiental = dht2.readTemperature();
    portENTER_CRITICAL(&muxSensors);
    if (!isnan(Lectura_De_Humedad_Incubadora))
      Point_Value_Humedad_Incubadora = Lectura_De_Humedad_Incubadora;
    if (!isnan(Lectura_De_Temperatura_Incubadora))
      Point_Value_Temperatura_Incubadora = Lectura_De_Temperatura_Incubadora;
    if (!isnan(Lectura_De_Temperatura_Ambiental))
      Point_Value_Temperatura_Ambiental = Lectura_De_Temperatura_Ambiental;
    portEXIT_CRITICAL(&muxSensors);
    vTaskDelayUntil(&Ultimo, pdMS_TO_TICKS(Tiempo_de_Muestreo));
    return poi
  }
}

void FeedForward()
{
  Lectura_de_sensores();
  portENTER_CRITICAL(&muxSensors);
  Temperatura_Ambiental = point
      // Aqui se realizara la recuperación de los parametros del proceso.
      //La detección del feedforward en la ecuación estatica pertenece a la lectura en tiempo...
      //Real del sensor DHT22 para estar a la par de la lectura.
      Feed_Forward_Temperatura = .3 * (Setpoint - 25) / K_Temperatura;
    Feed_Forward_Humedad = .3 * (Setpoint - 25) / K_Humedad;
}

void Calculo_Temperatura()
{
  // Calculo del sistema de temperatura en ecuaciones de diferencias.
  Y0_Temperatura[0] = Y0_Temperatura[1] * a0_T1[0] - X0_Temperatura[1]*b0_T1[0];
  for (int i = 3; i > 0; i--)
  {
    X0_Temperatura[i] = X0_Temperatura[i - 1];
    Y0_Temperatura[i] = Y0_Temperatura[i - 1];
  }
  //Configuracion_PID(tiemp)
}
void Calculo_Humedad()
{
  Y0_Humedad[0] = X0_Humedad[1]* a0_H1[0] - Y0_Humedad[1]*b0_H1[0];

  for (int i = 3; i > 0; i--)
  {
    X0_Humedad[i] = X0_Humedad[i - 1];
    Y0_Humedad[i] = Y0_Humedad[i - 1];
  }
}


void Calculo_PID_Temperatura()
{
  Calculo_Temperatura();
  Y0_PID_Temperatura[0] = X0_PID_Temperatura[0] * (Kpd + Kid + Kdd) - X0_PID_Temperatura[1] * (Kpd + 2 * Kdd) + X0_PID_Temperatura[2] * Kdd + Y0_PID_Temperatura[1];
  for (int i = 3; i > 0; i--)
  {
    X0_PID_Temperatura[i] = X0_PID_Temperatura[i - 1];
    Y0_PID_Temperatura[i] = Y0_PID_Temperatura[i - 1];
  }
}

void Calculo_PID_Humedad()
{
  Calculo_Humedad();
  Y0_PID_Humedad[0] = X0_PID_Humedad[0] * (Kpd + Kid + Kdd) - X0_PID_Humedad[1] * (Kpd + 2 * Kdd) + X0_PID_Humedad[2] * Kdd + Y0_PID_Humedad[1];
  for (int i = 3; i > 0; i--)
  {
    X0_PID_Humedad[i] = X0_PID_Humedad[i - 1];
    Y0_PID_Humedad[i] = Y0_PID_Humedad[i - 1];
  }
}

void Suma_Total()
{
  Calculo_PID_Humedad();
  Calculo_PID_Temperatura();
}

void setup()
{
  Serial.begin(115200);
  Tiempo_Anterior = micros();
  xTaskCreatePinnedToCore(Lectura_de_sensores, "DHT", 4096, nullptr, 1, nullptr, 0);
  pinMode(Ventilador, OUTPUT);
  pinMode(Calentador_Temperatura, OUTPUT);
  pinMode(Sistema_Dosificador_de_Humedad, OUTPUT);
  pinMode(Sensor_DHT22, INPUT);
  pinMode(Sensor_DHT22_Ambiental, INPUT);
  digitalWrite(Ventilador, HIGH);
  digitalWrite(Calentador_Temperatura, LOW);
  digitalWrite(Sistema_Dosificador_de_Humedad, LOW);

  ledcSetup(0, 5000, 12);
  ledcAttachPin(EnableA, 0);
  ledcSetup(3, 5000, 12);
  ledcAttachPin(EnableA_DER, 3);

  if (!LittleFS.begin(true))
    Serial.println("LittleFS mount falló");

  preferences.begin("wifi", false);
  ssidGuardado = preferences.getString("ssid", "");
  passGuardado = preferences.getString("password", "");
  preferences.end();

  webServer.on("/", manejarRaiz);
  webServer.on("/guardar", HTTP_POST, manejarGuardar);
  webServer.on("/escanear", HTTP_GET, manejarEscanear);
  webServer.onNotFound(manejarArchivo);
  webServer.begin();

  bool ok = false;
  if (ssidGuardado != "")
    ok = conectarWiFi(ssidGuardado, passGuardado);

  if (!ok)
  {
    Serial.println("Portal AP: " + String(AP_SSID));
    WiFi.mode(WIFI_AP_STA);
    WiFi.softAP(AP_SSID, AP_PASS);
    dnsServer.start(DNS_PORT, "*", WiFi.softAPIP());

    while (WiFi.status() != WL_CONNECTED)
    {
      dnsServer.processNextRequest();
      webServer.handleClient();
      delay(10);
    }
    dnsServer.stop();
  }

  Serial.print("WiFi OK · IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("Abre: http://");
  Serial.print(WiFi.localIP());
  Serial.println("/");
  Serial.println("Modo simulación disponible vía WS: {type:'set_sim', value:true|false}");

  wsServer.begin();
  wsServer.onEvent(onWsEvent);

  xTaskCreatePinnedToCore(tareaSensores, "DHT", 4096, nullptr, 1, nullptr, 0);

  ultimoPID = millis();
  ultimoWS = millis();
}

void loop()
{
  Tiempo_Actual = micros();
}
