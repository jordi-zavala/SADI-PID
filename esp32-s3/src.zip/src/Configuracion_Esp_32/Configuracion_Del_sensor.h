#pragma once
#include <DHT.h>

// Creacion de identificadores:
DHT dht1(Sensor_DHT22, TIPO_DHT);
DHT dht2(Sensor_DHT22_Ambiental, TIPO_DHT);

DNSServer dnsServer;
WebServer webServer(80);
Preferences preferences;


portMUX_TYPE muxSensors = portMUX_INITIALIZER_UNLOCKED;
