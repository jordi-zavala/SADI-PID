#pragma once
// Configuración de los tiempos del sistema.
constexpr double Tiempo_Maximo_Ejecucion = 1.2e3, Tiempo_de_Muestreo = 2;

constexpr double Tiempo_de_Subida_Sistema_Temperatura = 172.0,
                 Tiempo_de_Retardo_Sistema_Temperatura = 4,
                 Tiempo_de_Subida_Sensor_Temperatura = 26.38,
                 Tiempo_de_Retardo_Sensor_Temperatura = 4.2;

constexpr double Tiempo_de_Subida_Sistema_Humedad = 100.0,
                 Tiempo_de_Retardo_Sistema_Humedad = 4.2,
                 Tiempo_de_Subida_Sensor_Humedad = 26.38,
                 Tiempo_de_Retardo_Sensor_Humedad = 5.0;

constexpr double K_Temperatura = 68.50,
                 K_Humedad = 40, 
                 Setpoint_Temperatura = 37.5,
                 Setpoint_Humedad=60;

volatile float Point_Value_Humedad_Incubadora = NAN, Point_Value_Temperatura_Incubadora = NAN, Point_Value_Temperatura_Ambiental = NAN;

String usuarios_Permitidos[20];

String Nombre_Wifi_Guardado = "";
String Password_Wifi_Guardado = "";

// Configuración Puente H
constexpr int FREQ = 15000, RESOLUTION = 8;
constexpr int CH_RPWM = 0, CH_LPWM = 1;

float Feed_Forward_Temperatura, Feed_Forward_Humedad, Setpoint=37.5, Temperatura_Ambiental;

float aoT1 = 1 - exp(-Tiempo_de_Muestreo / Tiempo_de_Subida_Sistema_Temperatura), a1T1 = 0, a2T1 = 0;
float b0T1 = 0, b1T1 = 0, b2T1 = 0, b3T1 = 0;

float b0H1 = 0, b1H1 = 0, b2H1 = 0, b3H1 = 0;
float aoH1 = 0, a1H1 = 0, a2H1 = 0;

// Configuración de ecuaciones de diferencias (Temperatura).
float a0_T1[] = {aoT1, a1T1, a2T1};
float b0_T1[] = {b0T1, b1T1, b2T1, b3T1};

float aoT1 = 0, a1T1 = 0, a2T1 = 0;
float b0T1 = 0, b1T1 = 0, b2T1 = 0, b3T1 = 0;
// Configuración de ecuaciones de diferencias (Humedad).

float a0_H1[] = {aoH1, a1H1, a2H1};
float b0_H1[] = {b0H1, b1H1, b2H1, b3H1};

//Matrices de valores para el almacenamiento de la variables de la función de transferencia discreta
float X0_Temperatura[4] = {0, 0, 0, 0};
float Y0_Temperatura[4] = {0, 0, 0, 0};

float X0_Humedad[4] = {0, 0, 0, 0};
float Y0_Humedad[4] = {0, 0, 0, 0};

//Función de transferencia discreta PID - Temperatura
float X0_PID_Temperatura[4] = {0, 0, 0, 0};
float Y0_PID_Temperatura[4] = {0, 0, 0, 0};

//Función de transferencia discreta PID - Humedad
float X0_PID_Humedad[4] = {0, 0, 0, 0};
float Y0_PID_Humedad[4] = {0, 0, 0, 0};
