#pragma once
#define TIPO_DHT DHT22
#define Ventilador 5
#define Sensor_DHT22 44
#define Sensor_DHT22_Ambiental 43
#define Calentador_Temperatura 15
#define Sistema_Dosificador_de_Humedad 16
#define PIN_LPWM 16
#define PIN_ENC_B 26