#pragma once
#include <WiFi.h>
#include <ESPmDNS.h>
#include <WebServer.h>
#include <WiFiClientSecure.h>
#include <DNSServer.h>
#include <Preferences.h>

void Guardado_Wifi(){
  //int n = Wifi
}

void Escaneo_De_Archivos(){

}